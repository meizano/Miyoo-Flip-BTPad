# Changelog

## 0.1.0
- First public release.
- Presents the Miyoo Flip as a Bluetooth HID gamepad (16 buttons, hat, 4 axes).
- Built-in D-Bus client and ctypes L2CAP sockets (Spruce's Python has neither dbus nor Bluetooth sockets).
- Maps both sticks, stick clicks (L3/R3), D-pad and L2/R2.
- Built-in pairing agent ("just works", PIN `0000` fallback).
- Powers the Bluetooth adapter on itself (Spruce's toggle can disagree with the real state).
- Periodic report refresh so a dropped report cannot leave an input stuck.
- Diagnostics: `--check`, `--probe`, `--sticks`, `--nograb`, `--debug`.
