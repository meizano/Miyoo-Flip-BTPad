#!/usr/bin/env python3
"""
BTPad - turn a Miyoo Flip (SpruceOS) into a Bluetooth HID gamepad.

Usage:
    python3 btpad.py            run the pad (what launch.sh does)
    python3 btpad.py --check    report what this device has
    python3 btpad.py --probe    print raw button/stick events (to fix mapping.json)
                                (add --all to watch every input device, e.g. to find L3/R3)
    python3 btpad.py --sticks   show stick ranges: declared vs observed vs what is sent

Needs only: python3 (with ctypes), BlueZ (bluetoothd) and the D-Bus system bus. Flags: --debug (bluetoothd log), --nograb.
No dbus-python: a tiny D-Bus client is built in. Must run as root.
"""
import errno
import fcntl
import glob
import json
import math
import os
import select
import signal
import socket
import struct
import subprocess
import sys
import time

try:
    import ctypes
except ImportError:  # reported by --check
    ctypes = None

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = "Miyoo Flip Pad"
HID_UUID = "00001124-0000-1000-8000-00805f9b34fb"
PROFILE_PATH = "/miyoo/btpad"
PSM_CTRL, PSM_INTR = 0x11, 0x13
AF_BLUETOOTH, BTPROTO_L2CAP = 31, 0
EXIT_HOLD_SECONDS = 2.0  # hold L1+R1+Select+Start to quit

# ---------------------------------------------------------------- HID descriptor
# Report ID 1: 16 buttons | hat (4 bits) + 4 pad | X Y Z Rz (8 bit each)
REPORT_DESC = bytes([
    0x05, 0x01, 0x09, 0x05, 0xA1, 0x01, 0x85, 0x01,
    0x05, 0x09, 0x19, 0x01, 0x29, 0x10, 0x15, 0x00, 0x25, 0x01,
    0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
    0x05, 0x01, 0x09, 0x39, 0x15, 0x01, 0x25, 0x08, 0x35, 0x00,
    0x46, 0x3B, 0x01, 0x65, 0x14, 0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
    0x65, 0x00, 0x35, 0x00, 0x45, 0x00,
    0x75, 0x04, 0x95, 0x01, 0x81, 0x03,
    0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35,
    0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
    0xC0,
])

SDP_XML = """<?xml version="1.0" encoding="UTF-8" ?>
<record>
 <attribute id="0x0001"><sequence><uuid value="0x1124"/></sequence></attribute>
 <attribute id="0x0004"><sequence>
  <sequence><uuid value="0x0100"/><uint16 value="0x0011"/></sequence>
  <sequence><uuid value="0x0011"/></sequence></sequence></attribute>
 <attribute id="0x0005"><sequence><uuid value="0x1002"/></sequence></attribute>
 <attribute id="0x0006"><sequence><uint16 value="0x656e"/><uint16 value="0x006a"/><uint16 value="0x0100"/></sequence></attribute>
 <attribute id="0x0009"><sequence><sequence><uuid value="0x1124"/><uint16 value="0x0100"/></sequence></sequence></attribute>
 <attribute id="0x000d"><sequence><sequence>
  <sequence><uuid value="0x0100"/><uint16 value="0x0013"/></sequence>
  <sequence><uuid value="0x0011"/></sequence></sequence></sequence></attribute>
 <attribute id="0x0100"><text value="%(name)s"/></attribute>
 <attribute id="0x0101"><text value="Gamepad"/></attribute>
 <attribute id="0x0102"><text value="Miyoo"/></attribute>
 <attribute id="0x0200"><uint16 value="0x0100"/></attribute>
 <attribute id="0x0201"><uint16 value="0x0111"/></attribute>
 <attribute id="0x0202"><uint8 value="0x08"/></attribute>
 <attribute id="0x0203"><uint8 value="0x00"/></attribute>
 <attribute id="0x0204"><boolean value="true"/></attribute>
 <attribute id="0x0205"><boolean value="true"/></attribute>
 <attribute id="0x0206"><sequence><sequence><uint8 value="0x22"/><text encoding="hex" value="%(desc)s"/></sequence></sequence></attribute>
 <attribute id="0x0207"><sequence><sequence><uint16 value="0x0409"/><uint16 value="0x0100"/></sequence></sequence></attribute>
 <attribute id="0x020b"><uint16 value="0x0100"/></attribute>
 <attribute id="0x020c"><uint16 value="0x0c80"/></attribute>
 <attribute id="0x020d"><boolean value="true"/></attribute>
 <attribute id="0x020e"><boolean value="false"/></attribute>
 <attribute id="0x020f"><uint16 value="0x0640"/></attribute>
 <attribute id="0x0210"><uint16 value="0x0320"/></attribute>
</record>
""" % {"name": NAME, "desc": REPORT_DESC.hex()}

# ---------------------------------------------------------------- default mapping
# evdev key code -> HID button number (1-based), matching what Android expects:
# 1=A(south) 2=B(east) 4=X(north) 5=Y(west) 7=L1 8=R1 9=L2 10=R2 11=Select 12=Start 13=Mode
DEFAULT_KEYMAP = {304: 1, 305: 2, 307: 4, 308: 5, 310: 7, 311: 8,
                  314: 11, 315: 12, 316: 13, 317: 14, 318: 15}
DEFAULT_DPAD_KEYS = {103: "up", 108: "down", 105: "left", 106: "right",
                     544: "up", 545: "down", 546: "left", 547: "right"}
DEFAULT_AXES = {0: "lx", 1: "ly", 3: "rx", 4: "ry"}
DEFAULT_TRIGGER_AXES = {2: 9, 5: 10}  # Flip's L2/R2 are analog-style axes -> buttons 9/10
EXIT_COMBO = (310, 311, 314, 315)     # L1 R1 Select Start

EV_KEY, EV_ABS = 1, 3
ABS_HAT0X, ABS_HAT0Y = 16, 17
EVENT_FMT = "llHHi"
EVENT_SIZE = struct.calcsize(EVENT_FMT)


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


# ---------------------------------------------------------------- evdev helpers
def _ioc(direction, typ, nr, size):
    return (direction << 30) | (size << 16) | (ord(typ) << 8) | nr


def EVIOCGNAME(n): return _ioc(2, "E", 0x06, n)
def EVIOCGBIT(ev, n): return _ioc(2, "E", 0x20 + ev, n)
def EVIOCGABS(a): return _ioc(2, "E", 0x40 + a, 24)


EVIOCGRAB = _ioc(1, "E", 0x90, 4)


def ev_bits(fd, ev, nbytes=96):
    buf = bytearray(nbytes)
    try:
        fcntl.ioctl(fd, EVIOCGBIT(ev, nbytes), buf)
    except OSError:
        return set()
    return {i for i in range(nbytes * 8) if buf[i // 8] >> (i % 8) & 1}


def ev_name(fd):
    buf = bytearray(256)
    try:
        n = fcntl.ioctl(fd, EVIOCGNAME(256), buf)
        return bytes(buf[:n]).split(b"\0")[0].decode(errors="replace")
    except OSError:
        return "?"


def abs_range(fd, code):
    buf = bytearray(24)
    try:
        fcntl.ioctl(fd, EVIOCGABS(code), buf)
        _val, lo, hi, _fz, _fl, _res = struct.unpack("iiiiii", bytes(buf))
        return (lo, hi) if hi > lo else (0, 255)
    except OSError:
        return (0, 255)


class Pad:
    def __init__(self, path, fd, name, keys, absc):
        self.path, self.fd, self.name = path, fd, name
        self.keys, self.abs = keys, absc
        self.ranges = {c: abs_range(fd, c) for c in absc}


def open_pads(want=None):
    pads = []
    for path in sorted(glob.glob("/dev/input/event*")):
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        except OSError:
            continue
        name = ev_name(fd)
        keys, absc = ev_bits(fd, EV_KEY), ev_bits(fd, EV_ABS)
        looks_like_pad = bool(keys & set(range(0x130, 0x140))) or (0 in absc and 1 in absc)
        if want:
            ok = any(w in name or w == path for w in want)
        else:
            ok = looks_like_pad
        if ok:
            pads.append(Pad(path, fd, name, keys, absc))
        else:
            os.close(fd)
    return pads


# ---------------------------------------------------------------- pad state -> HID report
def scale_axis(value, lo, hi):
    """Raw evdev value -> 0..255 with a small centre dead zone."""
    v = int((value - lo) * 255 / (hi - lo))
    v = max(0, min(255, v))
    return 128 if abs(v - 128) < 8 else v


class State:
    def __init__(self, keymap, dpad_keys, axes, trig):
        self.keymap, self.dpad_keys, self.axes, self.trig = keymap, dpad_keys, axes, trig
        self.buttons = 0
        self.held = set()
        self.dir = {"up": 0, "down": 0, "left": 0, "right": 0}
        self.ax = {"lx": 128, "ly": 128, "rx": 128, "ry": 128}

    def hat(self):
        x = self.dir["right"] - self.dir["left"]
        y = self.dir["down"] - self.dir["up"]
        return {(0, -1): 1, (1, -1): 2, (1, 0): 3, (1, 1): 4,
                (0, 1): 5, (-1, 1): 6, (-1, 0): 7, (-1, -1): 8}.get((x, y), 0)

    def report(self):
        b, a = self.buttons, self.ax
        return bytes([0x01, b & 0xFF, (b >> 8) & 0xFF, self.hat(),
                      a["lx"], a["ly"], a["rx"], a["ry"]])

    def feed(self, pad, etype, code, value):
        """Returns True if the report changed."""
        before = self.report()
        if etype == EV_KEY:
            if value:
                self.held.add(code)
            else:
                self.held.discard(code)
            if code in self.keymap:
                bit = 1 << (self.keymap[code] - 1)
                self.buttons = (self.buttons | bit) if value else (self.buttons & ~bit)
            elif code in self.dpad_keys:
                self.dir[self.dpad_keys[code]] = 1 if value else 0
        elif etype == EV_ABS:
            if code == ABS_HAT0X:
                self.dir["left"], self.dir["right"] = int(value < 0), int(value > 0)
            elif code == ABS_HAT0Y:
                self.dir["up"], self.dir["down"] = int(value < 0), int(value > 0)
            elif code in self.trig:
                lo, hi = pad.ranges.get(code, (0, 255))
                bit = 1 << (self.trig[code] - 1)
                if value > lo + (hi - lo) * 0.5:
                    self.buttons |= bit
                else:
                    self.buttons &= ~bit
            elif code in self.axes:
                lo, hi = pad.ranges.get(code, (0, 255))
                self.ax[self.axes[code]] = scale_axis(value, lo, hi)
        return self.report() != before

    def exit_combo_held(self):
        return all(c in self.held for c in EXIT_COMBO)


def load_mapping():
    keymap, dpad_keys = dict(DEFAULT_KEYMAP), dict(DEFAULT_DPAD_KEYS)
    axes, trig, devices = dict(DEFAULT_AXES), dict(DEFAULT_TRIGGER_AXES), None
    p = os.path.join(HERE, "mapping.json")
    if os.path.exists(p):
        with open(p) as f:
            cfg = json.load(f)
        if "keys" in cfg:
            keymap = {int(k): int(v) for k, v in cfg["keys"].items()}
        if "dpad_keys" in cfg:
            dpad_keys = {int(k): v for k, v in cfg["dpad_keys"].items()}
        if "axes" in cfg:
            axes = {int(k): v for k, v in cfg["axes"].items()}
        if "trigger_axes" in cfg:
            trig = {int(k): int(v) for k, v in cfg["trigger_axes"].items()}
        devices = cfg.get("devices")
        log("loaded mapping.json")
    return keymap, dpad_keys, axes, trig, devices


# ---------------------------------------------------------------- tiny D-Bus client
def _align(b, n):
    b.extend(b"\0" * (-len(b) % n))


def _str(b, s):
    _align(b, 4)
    raw = s.encode()
    b.extend(struct.pack("<I", len(raw)) + raw + b"\0")


def _sig(b, s):
    raw = s.encode()
    b.append(len(raw))
    b.extend(raw + b"\0")


AGENT_PATH = "/miyoo/btpad_agent"


def _parse_fields(data):
    out, i = {}, 0
    while i < len(data):
        i += -i % 8
        if i >= len(data):
            break
        code = data[i]
        sl = data[i + 1]
        sig = data[i + 2:i + 2 + sl].decode()
        i += sl + 3
        if sig in ("o", "s"):
            i += -i % 4
            n = struct.unpack_from("<I", data, i)[0]
            i += 4
            out[code] = data[i:i + n].decode(errors="replace")
            i += n + 1
        elif sig == "g":
            n = data[i]
            out[code] = data[i + 1:i + 1 + n].decode()
            i += n + 2
        elif sig == "u":
            i += -i % 4
            out[code] = struct.unpack_from("<I", data, i)[0]
            i += 4
        else:
            break
    return out


class Bus:
    """Just enough D-Bus (system bus) for BlueZ: calls, property sets, and a pairing agent."""

    def __init__(self, path=None):
        if path is None:
            path = "/run/dbus/system_bus_socket"
            if not os.path.exists(path):
                path = "/var/run/dbus/system_bus_socket"
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(path)
        self.serial = 0
        self.sock.sendall(b"\0AUTH EXTERNAL " + str(os.getuid()).encode().hex().encode() + b"\r\n")
        buf = b""
        while not buf.endswith(b"\r\n"):
            chunk = self.sock.recv(256)
            if not chunk:
                raise OSError("bus closed during auth")
            buf += chunk
        if not buf.startswith(b"OK"):
            raise OSError("bus auth failed: %r" % buf)
        self.sock.sendall(b"BEGIN\r\n")
        rb = self.call("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "Hello")
        n = struct.unpack_from("<I", rb, 0)[0]
        self.name = rb[4:4 + n].decode()

    # -- wire helpers
    def _recv(self, n):
        out = b""
        while len(out) < n:
            c = self.sock.recv(n - len(out))
            if not c:
                raise OSError("bus closed")
            out += c
        return out

    def _read(self):
        h = self._recv(16)
        blen, serial, flen = struct.unpack("<III", h[4:16])
        pad = -flen % 8
        rest = self._recv(flen + pad + blen)
        return h[1], serial, _parse_fields(rest[:flen]), rest[flen + pad:]

    def _build(self, typ, flags, flds, body):
        self.serial += 1
        h = bytearray()
        for code, vsig, val in flds:
            _align(h, 8)
            h.append(code)
            _sig(h, vsig)
            if vsig in ("o", "s"):
                _str(h, val)
            elif vsig == "g":
                _sig(h, val)
            elif vsig == "u":
                _align(h, 4)
                h.extend(struct.pack("<I", val))
        msg = bytearray(struct.pack("<cBBBII", b"l", typ, flags, 1, len(body), self.serial))
        msg += struct.pack("<I", len(h)) + h
        _align(msg, 8)
        msg += body
        return bytes(msg)

    def _reply(self, to, req_serial, sig="", body=b""):
        flds = [(5, "u", req_serial), (6, "s", to)]
        if sig:
            flds.append((8, "g", sig))
        self.sock.sendall(self._build(2, 1, flds, body))

    def _error(self, to, req_serial, name, text):
        body = bytearray()
        _str(body, text)
        flds = [(4, "s", name), (5, "u", req_serial), (6, "s", to), (8, "g", "s")]
        self.sock.sendall(self._build(3, 1, flds, bytes(body)))

    def _handle(self, typ, serial, f, body):
        """Answer calls BlueZ makes to our pairing agent."""
        if typ != 1:
            return
        member, sender = f.get(3, ""), f.get(7, "")
        if f.get(1) == AGENT_PATH and f.get(2) == "org.bluez.Agent1":
            log("agent call:", member)
            if member == "RequestPinCode":
                b = bytearray()
                _str(b, "0000")
                self._reply(sender, serial, "s", bytes(b))
            elif member == "RequestPasskey":
                self._reply(sender, serial, "u", struct.pack("<I", 0))
            else:  # RequestConfirmation, RequestAuthorization, AuthorizeService, Cancel, Release...
                self._reply(sender, serial)
        else:
            self._error(sender, serial, "org.freedesktop.DBus.Error.UnknownMethod", "unknown method")

    def pump(self):
        """Read and answer one incoming message (call when the socket is readable)."""
        self.sock.settimeout(3)
        typ, serial, f, body = self._read()
        self._handle(typ, serial, f, body)

    # -- calls
    def call(self, dest, path, iface, member, sig="", body=b""):
        flds = [(1, "o", path), (2, "s", iface), (3, "s", member), (6, "s", dest)]
        if sig:
            flds.append((8, "g", sig))
        self.sock.sendall(self._build(1, 0, flds, body))
        while True:
            typ, serial, f, rbody = self._read()
            if typ == 2:
                return rbody
            if typ == 3:
                text = ""
                if len(rbody) >= 4:
                    n = struct.unpack("<I", rbody[:4])[0]
                    text = rbody[4:4 + n].decode(errors="replace")
                raise RuntimeError("D-Bus error: " + text)
            self._handle(typ, serial, f, rbody)

    def set_prop(self, prop, vsig, val, iface="org.bluez.Adapter1", path="/org/bluez/hci0"):
        body = bytearray()
        _str(body, iface)
        _str(body, prop)
        _sig(body, vsig)
        if vsig == "s":
            _str(body, val)
        else:  # "b" or "u"
            _align(body, 4)
            body += struct.pack("<I", int(val))
        self.call("org.bluez", path, "org.freedesktop.DBus.Properties", "Set", "ssv", bytes(body))

    def get_prop(self, prop, iface="org.bluez.Adapter1", path="/org/bluez/hci0"):
        body = bytearray()
        _str(body, iface)
        _str(body, prop)
        rb = self.call("org.bluez", path, "org.freedesktop.DBus.Properties", "Get", "ss", bytes(body))
        sl = rb[0]
        sig = rb[1:1 + sl].decode()
        i = 1 + sl + 1
        if sig == "b":
            i += -i % 4
            return bool(struct.unpack_from("<I", rb, i)[0])
        return None

    def register_agent(self):
        body = bytearray()
        _str(body, AGENT_PATH)
        _str(body, "NoInputNoOutput")
        self.call("org.bluez", "/org/bluez", "org.bluez.AgentManager1", "RegisterAgent", "os", bytes(body))
        body = bytearray()
        _str(body, AGENT_PATH)
        self.call("org.bluez", "/org/bluez", "org.bluez.AgentManager1", "RequestDefaultAgent", "o", bytes(body))

    def unregister_agent(self):
        body = bytearray()
        _str(body, AGENT_PATH)
        self.call("org.bluez", "/org/bluez", "org.bluez.AgentManager1", "UnregisterAgent", "o", bytes(body))

    def register_profile(self):
        body = bytearray()
        _str(body, PROFILE_PATH)
        _str(body, HID_UUID)
        _align(body, 4)
        lenpos = len(body)
        body += b"\0\0\0\0"
        _align(body, 8)
        start = len(body)
        for key, vsig, val in (("ServiceRecord", "s", SDP_XML), ("Role", "s", "server"),
                               ("RequireAuthentication", "b", False),
                               ("RequireAuthorization", "b", False),
                               ("AutoConnect", "b", False)):
            _align(body, 8)
            _str(body, key)
            _sig(body, vsig)
            if vsig == "s":
                _str(body, val)
            else:
                _align(body, 4)
                body += struct.pack("<I", int(val))
        struct.pack_into("<I", body, lenpos, len(body) - start)
        self.call("org.bluez", "/org/bluez", "org.bluez.ProfileManager1",
                  "RegisterProfile", "osa{sv}", bytes(body))


# ---------------------------------------------------------------- bluetooth plumbing
def bluetoothd_info():
    """-> (pid, argv with real exe path, cwd) or (None, None, None)"""
    for p in os.listdir("/proc"):
        if not p.isdigit():
            continue
        try:
            with open("/proc/%s/comm" % p) as f:
                if f.read().strip() != "bluetoothd":
                    continue
            with open("/proc/%s/cmdline" % p, "rb") as f:
                args = [a.decode() for a in f.read().split(b"\0") if a]
            if not args:
                continue
            try:
                exe = os.readlink("/proc/%s/exe" % p).replace(" (deleted)", "")
            except OSError:
                exe = args[0]
            try:
                cwd = os.readlink("/proc/%s/cwd" % p)
            except OSError:
                cwd = "/"
            return int(p), [exe] + args[1:], cwd
        except OSError:
            pass
    return None, None, None


def restart_bluetoothd(args, cwd, logfile=None):
    pid = bluetoothd_info()[0]
    if pid:
        os.kill(pid, signal.SIGTERM)
        for _ in range(30):
            if bluetoothd_info()[0] is None:
                break
            time.sleep(0.2)
    time.sleep(0.5)
    out = open(logfile, "ab") if logfile else subprocess.DEVNULL
    subprocess.Popen(args, cwd=cwd, stdout=out, stderr=out, start_new_session=True)
    time.sleep(1.5)


def l2cap_accept(lsock):
    """accept() via libc: Python's socket.accept() raises 'bad family' for Bluetooth here."""
    libc = ctypes.CDLL(None, use_errno=True)
    fd = libc.accept(lsock.fileno(), None, None)
    if fd < 0:
        e = ctypes.get_errno()
        raise OSError(e, os.strerror(e))
    return socket.socket(AF_BLUETOOTH, socket.SOCK_SEQPACKET, BTPROTO_L2CAP, fileno=fd)


def make_listener(psm):
    """L2CAP listening socket. This Python lacks socket.AF_BLUETOOTH, so bind via libc."""
    s = socket.socket(AF_BLUETOOTH, socket.SOCK_SEQPACKET, BTPROTO_L2CAP)
    addr = struct.pack("<HH6sHBx", AF_BLUETOOTH, psm, b"\0" * 6, 0, 0)
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.bind(s.fileno(), addr, len(addr)) != 0:
        e = ctypes.get_errno()
        s.close()
        raise OSError(e, os.strerror(e))
    s.listen(1)
    return s


def unblock_bluetooth():
    for d in glob.glob("/sys/class/rfkill/rfkill*"):
        try:
            with open(d + "/type") as f:
                if f.read().strip() != "bluetooth":
                    continue
            with open(d + "/soft", "w") as f:
                f.write("0")
        except OSError:
            pass


def ensure_powered(bus):
    """Spruce can show Bluetooth as 'on' while the adapter is actually off; make sure it's on."""
    for attempt in range(12):
        try:
            if bus.get_prop("Powered"):
                return True
        except Exception as e:
            log("adapter not ready yet:", e)
        unblock_bluetooth()
        try:
            bus.set_prop("Powered", "b", True)
        except Exception as e:
            log("power on failed:", e)
        if attempt == 3:
            try:
                subprocess.run(["hciconfig", "hci0", "up"], stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
            except OSError:
                pass
        time.sleep(1)
    log("WARNING: the Bluetooth adapter is still powered off; the tablet will not see the Flip")
    return False


def setup_adapter(bus):
    if ensure_powered(bus):
        log("adapter powered on")
    time.sleep(0.5)
    for prop, vsig, val in (("Alias", "s", NAME), ("Pairable", "b", True),
                            ("DiscoverableTimeout", "u", 0), ("Discoverable", "b", True)):
        try:
            bus.set_prop(prop, vsig, val)
        except Exception as e:
            log("could not set %s: %s" % (prop, e))
    try:
        bus.register_agent()
    except Exception as e:
        log("could not register pairing agent:", e)


def log_adapter_info():
    for cmd in (["hciconfig", "hci0", "-a"], ["hciconfig", "hci0", "sspmode"]):
        try:
            out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 universal_newlines=True).stdout
        except OSError:
            continue
        for line in out.splitlines():
            if any(k in line for k in ("Name", "Class", "UP", "SSP", "BD Address")):
                log("hci:", line.strip())


def set_device_class():
    try:
        r = subprocess.run(["hciconfig", "hci0", "class", "0x002508"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if r.returncode == 0:
            return
    except OSError:
        pass
    log("could not set gamepad device class (not fatal)")


# ---------------------------------------------------------------- modes
def do_check():
    print("python", sys.version.split()[0])
    print("ctypes:", "OK" if ctypes else "MISSING  <- required")
    try:
        s = socket.socket(AF_BLUETOOTH, socket.SOCK_SEQPACKET, BTPROTO_L2CAP)
        s.close()
        print("L2CAP socket: OK")
    except OSError as e:
        print("L2CAP socket: FAILED", e)
    try:
        Bus()
        print("D-Bus system bus: OK")
    except Exception as e:
        print("D-Bus system bus: FAILED", e)
    for tool in ("hciconfig",):
        found = any(os.access(os.path.join(d, tool), os.X_OK) for d in os.environ.get("PATH", "").split(":"))
        print("%-13s %s" % (tool, "found" if found else "not in PATH"))
    print("bluetoothd:", bluetoothd_info())
    print("uid:", os.getuid(), "(needs 0)")
    print("pads that will be used:", [p.name for p in open_pads(load_mapping()[4])])


def do_probe(want):
    pads = open_pads(want)
    if not pads:
        print("no gamepad-like input devices found")
        return
    for p in pads:
        print("watching", p.path, p.name)
    print("press buttons / move sticks (Ctrl-C to stop)")
    byfd = {p.fd: p for p in pads}
    try:
        while True:
            r, _, _ = select.select(list(byfd), [], [], 1)
            for fd in r:
                data = os.read(fd, EVENT_SIZE * 32)
                for off in range(0, len(data) - EVENT_SIZE + 1, EVENT_SIZE):
                    _s, _u, t, c, v = struct.unpack(EVENT_FMT, data[off:off + EVENT_SIZE])
                    if t in (EV_KEY, EV_ABS):
                        print("%s  %s code=%d value=%d" % (byfd[fd].name, "KEY" if t == EV_KEY else "ABS", c, v))
    except KeyboardInterrupt:
        pass


def do_sticks(want):
    """Show declared range, observed range and what BTPad would send for each stick axis."""
    _k, _d, axes, _t, _w = load_mapping()
    pads = open_pads(want)
    if not pads:
        print("no gamepad-like input devices found")
        return
    obs, ranges, radius = {}, {}, {}
    for p in pads:
        for c in sorted(set(axes) & p.abs):
            ranges[c] = p.ranges[c]
            print("axis %d (%s): declared range %s" % (c, axes[c], p.ranges[c]))
    print("Rotate each stick slowly around its edge a few times, then push it halfway left and hold.")
    print("Ctrl-C prints a summary.")
    byfd = {p.fd: p for p in pads}
    last, shown = {}, 0.0
    try:
        while True:
            r, _, _ = select.select(list(byfd), [], [], 0.2)
            for fd in r:
                data = os.read(fd, EVENT_SIZE * 64)
                for off in range(0, len(data) - EVENT_SIZE + 1, EVENT_SIZE):
                    _s, _u, t, c, v = struct.unpack(EVENT_FMT, data[off:off + EVENT_SIZE])
                    if t == EV_ABS and c in ranges:
                        o = obs.setdefault(c, [v, v])
                        o[0], o[1] = min(o[0], v), max(o[1], v)
                        last[c] = v
                        for a, b in (("lx", "ly"), ("rx", "ry")):
                            ca = next((k for k, n in axes.items() if n == a), None)
                            cb = next((k for k, n in axes.items() if n == b), None)
                            if c in (ca, cb) and ca in last and cb in last:
                                r_ = math.hypot(last[ca] / float(ranges[ca][1]), last[cb] / float(ranges[cb][1]))
                                radius[a[0]] = max(radius.get(a[0], 0.0), r_)
            if time.time() - shown > 0.3 and last:
                shown = time.time()
                print("\r" + "  ".join("%s raw=%6d sent=%3d" % (
                    axes[c], v, scale_axis(v, *ranges[c])) for c, v in sorted(last.items())), end="   ", flush=True)
    except KeyboardInterrupt:
        pass
    print("\n--- summary ---")
    for c, (lo, hi) in sorted(ranges.items()):
        o = obs.get(c)
        if not o:
            print("%s: no movement seen" % axes[c])
            continue
        note = "  <-- goes OUTSIDE the declared range (BTPad clips it)" if o[0] < lo or o[1] > hi else ""
        print("%s: declared %s, observed %d..%d%s" % (axes[c], (lo, hi), o[0], o[1], note))
    for side, name in (("l", "left"), ("r", "right")):
        if side in radius:
            print("%s stick: furthest reach = %.2f x full range (1.00 = round gate, 1.41 = square corners)"
                  % (name, radius[side]))


def run():
    keymap, dpad_keys, axes, trig, want = load_mapping()
    debug = "--debug" in sys.argv
    grab = "--nograb" not in sys.argv
    running = [True]
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: running.__setitem__(0, False))

    pads = open_pads(want)
    if not pads:
        log("no gamepad input devices found; run --check / --probe")
        return 1
    for p in pads:
        log("using", p.path, p.name)
        if grab:
            try:
                fcntl.ioctl(p.fd, EVIOCGRAB, 1)  # keep Spruce from also reacting to the buttons
            except OSError:
                log("could not grab", p.path)
    if grab:
        log("buttons are grabbed: Spruce's screen will not respond while this runs")
    log("to quit: hold L1+R1+Select+Start for 2s, or press Ctrl-C here")

    original_btd = None
    btd_log = os.path.join(HERE, "bluetoothd.log") if debug else None
    _pid, args, cwd = bluetoothd_info()
    if not args:
        log("bluetoothd is not running - turn Bluetooth on in Spruce first")
        return 1
    if "--noplugin=input" not in args:
        # BlueZ's input plugin owns the HID UUID and ports, which blocks HID *device* mode
        log("restarting bluetoothd without its input plugin (needed to act as a HID device)")
        original_btd = (args, cwd)
        restart_bluetoothd(args + ["--noplugin=input"] + (["-d"] if debug else []), cwd, btd_log)
    ctrl_l, intr_l = make_listener(PSM_CTRL), make_listener(PSM_INTR)

    bus = Bus()
    deadline = time.time() + 15
    while True:
        try:
            bus.register_profile()
            break
        except RuntimeError as e:
            if "org.bluez" not in str(e) or time.time() > deadline:
                raise
            log("waiting for bluez:", e)
            time.sleep(1)
    setup_adapter(bus)
    set_device_class()
    log_adapter_info()
    log("ready: on the tablet, scan for '%s' and pair" % NAME)

    state = State(keymap, dpad_keys, axes, trig)
    byfd = {p.fd: p for p in pads}
    conn = {"ctrl": None, "intr": None}
    exit_since = None

    def drop():
        for k in ("ctrl", "intr"):
            if conn[k]:
                try:
                    conn[k].close()
                except OSError:
                    pass
                conn[k] = None
        log("host disconnected; waiting for reconnect")

    last_push = [0.0]

    def push():
        if conn["intr"]:
            try:
                conn["intr"].send(b"\xA1" + state.report())
                last_push[0] = time.time()
            except OSError:
                drop()

    def handle_ctrl():
        try:
            data = conn["ctrl"].recv(64)
        except OSError:
            data = b""
        if not data:
            drop()
            return
        t = data[0] >> 4
        try:
            if t == 0x1 and (data[0] & 0xF) == 5:      # virtual cable unplug
                drop()
            elif t == 0x4:                              # GET_REPORT
                conn["ctrl"].send(b"\xA1" + state.report())
            elif t == 0x6:                              # GET_PROTOCOL -> report mode
                conn["ctrl"].send(b"\xA0\x01")
            elif t == 0x8:                              # GET_IDLE
                conn["ctrl"].send(b"\xA0\x00")
            elif t in (0x5, 0x7, 0x9):                  # SET_REPORT/PROTOCOL/IDLE -> success
                conn["ctrl"].send(b"\x00")
        except OSError:
            drop()

    try:
        while running[0]:
            rl = [ctrl_l, intr_l, bus.sock] + list(byfd) + [c for c in conn.values() if c]
            try:
                ready, _, _ = select.select(rl, [], [], 0.05)
            except InterruptedError:
                continue
            for s in ready:
                if s is bus.sock:
                    try:
                        bus.pump()
                    except (OSError, socket.timeout) as e:
                        log("D-Bus connection problem:", e)
                        running[0] = False
                elif s is ctrl_l:
                    if conn["ctrl"]:
                        conn["ctrl"].close()
                    conn["ctrl"] = l2cap_accept(ctrl_l)
                    log("control channel connected")
                elif s is intr_l:
                    if conn["intr"]:
                        conn["intr"].close()
                    conn["intr"] = l2cap_accept(intr_l)
                    log("interrupt channel connected - pad is live")
                    push()
                elif s is conn["ctrl"]:
                    handle_ctrl()
                elif s in byfd:
                    pad = byfd[s]
                    try:
                        data = os.read(s, EVENT_SIZE * 64)
                    except BlockingIOError:
                        continue
                    changed = False
                    for off in range(0, len(data) - EVENT_SIZE + 1, EVENT_SIZE):
                        _sec, _usec, t, c, v = struct.unpack(EVENT_FMT, data[off:off + EVENT_SIZE])
                        if t in (EV_KEY, EV_ABS):
                            changed |= state.feed(pad, t, c, v)
                    if changed:
                        push()
                elif s is conn["intr"]:
                    try:
                        if not conn["intr"].recv(64):
                            drop()
                    except OSError:
                        drop()
            if conn["intr"] and time.time() - last_push[0] > 0.1:
                push()  # keep-alive: re-send the current state so a lost report cannot stick
            if state.exit_combo_held():
                exit_since = exit_since or time.time()
                if time.time() - exit_since > EXIT_HOLD_SECONDS:
                    log("exit combo held, quitting")
                    break
            else:
                exit_since = None
    finally:
        drop()
        for fn in (lambda: bus.set_prop("Discoverable", "b", False), bus.unregister_agent):
            try:
                fn()
            except Exception:
                pass
        for l in (ctrl_l, intr_l):
            l.close()
        bus.sock.close()
        for p in pads:
            try:
                fcntl.ioctl(p.fd, EVIOCGRAB, 0)
                os.close(p.fd)
            except OSError:
                pass
        if original_btd:
            log("restoring bluetoothd")
            try:
                restart_bluetoothd(original_btd[0], original_btd[1])
            except Exception as e:
                log("could not restore bluetoothd (%s); restore by hand: %s" % (e, " ".join(original_btd[0])))
    return 0


if __name__ == "__main__":
    if "--check" in sys.argv:
        do_check()
    elif "--sticks" in sys.argv:
        do_sticks(load_mapping()[4])
    elif "--probe" in sys.argv:
        do_probe([""] if "--all" in sys.argv else load_mapping()[4])
    else:
        sys.exit(run())
