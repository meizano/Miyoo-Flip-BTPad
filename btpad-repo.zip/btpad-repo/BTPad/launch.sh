#!/bin/sh
# BTPad launcher for SpruceOS (Miyoo Flip)
APPDIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APPDIR" || exit 1

PY=""
for c in /mnt/sdcard/spruce/flip/bin/python3 /mnt/SDCARD/spruce/flip/bin/python3 /root/bin/python3 python3; do
    if [ -x "$c" ] || command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
[ -z "$PY" ] && { echo "no python found" > btpad.log; exit 1; }

echo "=== $(date) ===" >> btpad.log
"$PY" btpad.py >> btpad.log 2>&1
